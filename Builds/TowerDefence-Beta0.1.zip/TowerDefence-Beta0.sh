#!/bin/sh
printf '\033c\033]0;%s\a' TowerDefence
base_path="$(dirname "$(realpath "$0")")"
"$base_path/TowerDefence-Beta0.1" "$@"
